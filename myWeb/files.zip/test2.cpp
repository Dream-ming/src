#include <iostream>

int main()
{
    std::cout << "Man, what can I say...\n";
    return 0;
}

