#include <iostream>

int main()
{
    std::cout << "What can I say, man...\n";
    return 0;
}

